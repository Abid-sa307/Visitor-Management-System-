# Notification Sound File

This file should be replaced with an actual 15-second MP3 notification sound.

You can:
1. Download a notification sound from freesound.org or similar sites
2. Use an online audio converter to ensure it's MP3 format
3. Trim it to exactly 15 seconds if needed
4. Replace this file with your chosen notification sound

The sound will play automatically when:
- A visitor is created and auto-approved
- A visitor's status is manually changed to "Approved"